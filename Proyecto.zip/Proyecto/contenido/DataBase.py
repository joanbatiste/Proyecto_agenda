import sqlite3

def CrearConexion(nombre):
    conexion = sqlite3.connect(nombre + ".db")
    return conexion

def CrearCursor(conexion):
    cursor = conexion.cursor()
    return cursor


def CrearTablaContactos(conexion, cursor):
    query = "CREATE TABLE IF NOT EXISTS Contactos ( id INTEGER, nombre varchar(60), apellidos varchar (255), direccion varchar (255), email varchar (120), telefono varchar (9), PRIMARY KEY (id AUTOINCREMENT))"
    cursor.execute(query)
    conexion.commit()

def CrearTablaUsuarios(conexion, cursor):
    query = "CREATE TABLE IF NOT EXISTS Usuarios ( Id INTEGER, usuario varchar (60), contraseña varchar (60), PRIMARY KEY ( Id AUTOINCREMENT))"
    cursor.execute(query)
    conexion.commit()